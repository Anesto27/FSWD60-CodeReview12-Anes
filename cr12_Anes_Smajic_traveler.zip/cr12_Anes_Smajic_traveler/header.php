
<!DOCTYPE html>
<html lang="en">
 <head>
   <meta charset="<?php bloginfo('charset'); ?>">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1">
   <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="<?php bloginfo('description'); ?>">
   <title><?php bloginfo('name'); ?></title>
   <!-- Bootstrap core CSS -->
    <link href="<?php bloginfo('template_url'); ?>/css/bootstrap.css" rel="stylesheet"><!--URL of the active theme's directory-->
    <!-- Custom styles for this template -->
    <link href="<?php bloginfo('stylesheet_url'); ?>" rel="stylesheet"> <!--displays the primary CSS-->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
    <?php wp_head(); ?>

  </head>
 <body>
  
     <div class="container-fluid">
  <nav class="navbar navbar-inverse blog-nav">
  <div class="container-fluid">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand" href="#">Agency</a>
    </div>
  <div class="row">
    <div class="col-md-7">
      
    
      <?php
            wp_nav_menu( array(
               'theme_location'    => 'primary',
               'depth'             => 2, //1 = no dropdowns, 2 = with dropdowns.
               'container'         => 'div',
               'container_class'   => 'collapse navbar-collapse',
               'container_id'      => 'bs-example-navbar-collapse-1',
               'menu_class'        => 'nav navbar-nav',
               'fallback_cb'       => 'WP_Bootstrap_Navwalker::fallback',
               'walker'            => new WP_Bootstrap_Navwalker(),
) );


?>
  
</div>



<div class="col-md-4">
  <form class="navbar-form navbar-left">
  <div class="form-group">
    <i class="fab fa-facebook-f"></i>
   <i class="fab fa-instagram"></i>
    <i class="fab fa-twitter"></i>
    <i class="fab fa-google"></i>
   <i class="fab fa-youtube"></i>
   <i class="fab fa-tumblr-square"></i>
    <i class="far fa-heart"></i>
          <input type="text" class="form-control" placeholder="Search">
        </div>
      </form>
</div>
        
  </div>
 </div>
    
  </nav>
</div>




   <div class="container-fluid">
     <div class="blog-header">
       <center><h1 class="blog-title"><?php bloginfo('name'); ?></h1></center>
       <hr class="line1">
       <center><p class="lead blog-description"><?php bloginfo('description'); ?></p></center>
     </div>