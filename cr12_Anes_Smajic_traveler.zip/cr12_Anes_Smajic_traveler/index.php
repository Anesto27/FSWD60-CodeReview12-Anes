<?php get_header(); ?>
 

    <div class="container-fluid">

        <?php query_posts('post_type=post&post_status=publish&posts_per_page=10&paged='. get_query_var('paged')); ?>
<?php 
    // Get total posts
    $total = $wp_query->post_count;

    // Set indicator to 0;
    $i = 0;
    ?>



       <?php if ( $i == 0 ) echo '<div class="row">'; ?>

        <?php if( have_posts() ): ?>

            <?php while( have_posts() ): the_post(); ?>

            <div class="col-md-3 col-sm-3" style="margin-bottom: 65px;">

            <p>
                <?php if ( has_post_thumbnail() ) : ?>
                                <a href="<?php the_permalink(); ?>"><?php the_post_thumbnail( 'large' ); ?></a>
                <?php endif; ?>
            </p>

            <h3 class="middle"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
            <hr class="line">
             <?php the_content(); ?><!--retrieves content-->


            <p>Posted on <?php echo the_time('F jS, Y');?> by <?php the_author_posts_link(); ?> </p>

         

            </div><!-- col -->
            <?php $i++; ?>
            <?php
        // if we're at the end close the row
        if ( $i == $total ) { 
            echo '</div>';
        } else {
            /** 
             * Perform modulus calculation to check whether $i / 2 is whole number
             * if true close row and open a new one
             */
            if ( $i % 3 == 0 ) {
                echo '</div><div class="row">';
            }
        }
        ?>

       
            <?php endwhile; ?>
            <div class="col-md-2 col-sm-2">
 <?php
      if(is_active_sidebar('sidebar')):
     dynamic_sidebar('sidebar');
     endif;  
?>
</div>
         </div><!-- row -->


        <div>
            <span><?php previous_posts_link(__('« Newer','example')) ?></span> <span class="older"><?php next_posts_link(__('Older »','example')) ?></span>
        </div><!-- /.navigation -->

    <?php else: ?>

        <div id="post-404">

            <p><?php _e('None found.','example'); ?></p>

        </div><!-- /#post-404 -->

    <?php endif; wp_reset_query(); ?>
  
    </div><!-- /#content -->


  <?php get_footer(); ?>