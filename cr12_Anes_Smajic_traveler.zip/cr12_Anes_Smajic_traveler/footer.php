
<div class="container-fluid">
	 <center><h4><?php single_post_title(); ?></h4></center>
	<div class="row">
		<div class="col-md-2 col-sm-4 offset-sm-2">
		<img class="img-responsive" src="<?php echo get_template_directory_uri(); ?>/img/travel1.jpeg" alt="image" width=200px >
	</div>
		<div class="col-md-2 col-sm-4 offset-sm-2">
		<img class="img-responsive" src="<?php echo get_template_directory_uri(); ?>/img/travel2.jpg" alt="image" width=200px >
	</div>
	<div class="col-md-2 col-sm-4 offset-sm-2">
		<img class="img-responsive" src="<?php echo get_template_directory_uri(); ?>/img/travel3.jpg" alt="image" width=200px >
	</div>
	<div class="col-md-2 col-sm-4 offset-sm-2">
		<img class="img-responsive" src="<?php echo get_template_directory_uri(); ?>/img/tavel4.jpeg" alt="image" width=200px >
	</div>
	<div class="col-md-2 col-sm-4 offset-sm-2">
		<img class="img-responsive" src="<?php echo get_template_directory_uri(); ?>/img/travel5.jpeg" alt="image" width=200px >
	</div>
	<div class="col-md-2 col-sm-4 offset-sm-2">
		<img class="img-responsive" src="<?php echo get_template_directory_uri(); ?>/img/travel6.jpeg" alt="image" width=200px >
		</div>
	</div>
<footer class="blog-footer">
	<i class="fab fa-facebook-f fa1"> Facebook</i>
   	<i class="fab fa-instagram fa1"> Instagram</i>
    <i class="fab fa-twitter fa1"> Twitter</i>
    <i class="fab fa-google fa1"> Google</i>
   	<i class="fab fa-youtube fa1"> Youtube</i>
   	<i class="fab fa-tumblr-square fa1"> Tumblr</i>
    <i class="far fa-heart fa1"> Bloglovin</i>
    <hr class="line2">
	
     <p>&copy; <?php echo Date('Y'); ?> <?php bloginfo('name'); ?></p>
     <p>
       <a href="#">Back to top</a>
     </p>
   </footer>
</div>
   <?php wp_footer(); ?>


   <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
  <script src="<?php bloginfo('template_url'); ?>/js/bootstrap.js"></script>
 </body>
</html>